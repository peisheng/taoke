﻿using System;
using System.Xml.Serialization;
using Top.Api;

namespace DingTalk.Api
{
    [Serializable]
    public abstract class DingTalkResponse : TopResponse
    {

    }
}
